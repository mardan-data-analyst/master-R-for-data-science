df <- read.csv(file.path("C:/Users/LinkedIn Instructor/Desktop/Exercise Files/Data Sources/","binomial (training).csv"))
logit <- glm(Win.Loss..Win.1..Loss.0. ~ Points.Team.Scored, data = df, family = "binomial")
summary(logit)