df <- read.csv(file.path("C:/Users/LinkedIn Instructor/Desktop/Exercise Files/Data Sources/","binomial (training).csv"))
logit <- glm(Win.Loss..Win.1..Loss.0. ~ Points.Team.Scored, data = df, family = "binomial")
summary(logit)

df$Predicted <- predict(logit, newdata = df, type = "response")
df$Predict.0.1 <- ifelse(df$Predicted > 0.5, 1, 0)

df <- df[order(df$Points.Team.Scored),]
plot(df$Points.Team.Scored, df$Win.Loss..Win.1..Loss.0., col = "orange", pch = 20, main = "Points Scored vs. Outcome", xlab = "Points Scored", ylab = "Win or Loss")
lines(df$Points.Team.Scored, df$Predicted, col = "blue")