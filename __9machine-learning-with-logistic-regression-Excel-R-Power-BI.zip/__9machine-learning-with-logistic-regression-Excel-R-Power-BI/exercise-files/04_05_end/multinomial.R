install.packages("mlogit")

library(mlogit)
data(package='mlogit')

data("Fishing", package='mlogit')
df <- mlogit.data(Fishing, choice="mode", shape="wide")

logit <- mlogit(mode ~ 1|income, data = df, reflevel = "pier")
summary(logit)

df1 <- subset(df, mode == 'TRUE')
df2 <- predict(logit, newdata = df)

df1
df2

nrow(df1)
nrow(df2)

outcomes <- cbind(df1,df2)
totals <- aggregate(cbind(outcomes$beach, outcomes$boat, outcomes$charter, outcomes$pier), by=list(income = outcomes$income), FUN=sum)
names(totals)[names(totals)=="V1"] <- "Beach"
names(totals)[names(totals)=="V2"] <- "Boat"
names(totals)[names(totals)=="V3"] <- "Charter"
names(totals)[names(totals)=="V4"] <- "Pier"
totals