install.packages("mlogit")

library(mlogit)
data(package='mlogit')

data("Fishing", package='mlogit')
df <- mlogit.data(Fishing, choice="mode", shape="wide")
df