df1 <- read.csv(file.path("C:/Users/LinkedIn Instructor/Desktop/Exercise Files/Data Sources/","binomial (training).csv"))
df2 <- read.csv(file.path("C:/Users/LinkedIn Instructor/Desktop/Exercise Files/Data Sources/","binomial (testing).csv"))

logit <- glm(Win.Loss..Win.1..Loss.0. ~ Points.Team.Scored + Home.Away..Home.1..Away.0. + Field.Goal.., data = df1, family = "binomial")
summary(logit)

#names(df1)

df2$Predicted <- predict(logit, newdata = df2, type = "response")
df2$Predict.0.1 <- ifelse(df2$Predicted > 0.5, 1, 0)

ct1 <- data.frame(prop.table(table(df2$Win.Loss..Win.1..Loss.0., df2$Predict.0.1)))

logit <- glm(Win.Loss..Win.1..Loss.0. ~ Points.Team.Scored + Home.Away..Home.1..Away.0., data = df1, family = "binomial")
df2$Predicted <- predict(logit, newdata = df2, type = "response")
df2$Predict.0.1 <- ifelse(df2$Predicted > 0.5, 1, 0)

ct2 <- data.frame(prop.table(table(df2$Win.Loss..Win.1..Loss.0., df2$Predict.0.1)))