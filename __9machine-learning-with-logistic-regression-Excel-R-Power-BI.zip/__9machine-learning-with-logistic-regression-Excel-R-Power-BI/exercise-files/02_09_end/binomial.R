df <- read.csv(file.path("C:/Users/LinkedIn Instructor/Desktop/Exercise Files/Data Sources/","binomial (training).csv"))
#names(df)
logit <- glm(Win.Loss..Win.1..Loss.0. ~ Rebounds, data = df, family = "binomial")
summary(logit)

df$Predicted <- predict(logit, newdata = df, type = "response")
df$Predict.0.1 <- ifelse(df$Predicted > 0.5, 1, 0)

df <- df[order(df$Rebounds),]
df
#plot(df$Rebounds, df$Win.Loss..Win.1..Loss.0.)#, col = "orange", pch = 20, main = "Rebounds vs. Outcome", xlab = "Rebounds", ylab = "Win or Loss")
lines(df$Rebounds, df$Predicted, col = "blue")