install.packages("mlogit")

library(mlogit)
data(package='mlogit')

data("Fishing", package='mlogit')
df <- mlogit.data(Fishing, choice="mode", shape="wide")

logit <- mlogit(mode ~ 1|income, data = df, reflevel = "pier")
summary(logit)