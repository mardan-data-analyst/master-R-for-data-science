df <- read.csv(file.path("C:/Users/LinkedIn Instructor/Desktop/Exercise Files/Data Sources/","binomial (training).csv"))
logit <- glm(Win.Loss..Win.1..Loss.0. ~ Points.Team.Scored, data = df, family = "binomial")
summary(logit)

df$Predicted <- predict(logit, newdata = df, type = "response")
df$Predict.0.1 <- ifelse(df$Predicted > 0.5, 1, 0)
df