install.packages("stylo")
library(stylo)

stylo()

