validSolution <- c(4,6,6,2,7,1,3,5)

is_this_a_valid_8_queens <- function(potentialSolution) {
  
  # check for diagonal conflicts
  for (eachElement in 1:8) {
    diagonal_conflicts <- createDiagValues(potentialSolution[eachElement], eachElement, 1)
    areThereDiagonalConflicts <- potentialSolution - diagonal_conflicts
    if (any(areThereDiagonalConflicts == 0)) {return(FALSE)}
    
    diagonal_conflicts <- createDiagValues(potentialSolution[eachElement], eachElement, -1)
    areThereDiagonalConflicts <- potentialSolution - diagonal_conflicts
    if (any(areThereDiagonalConflicts == 0)) {return(FALSE)}
  }
  
  # if we made it this far, it's a valid solution
  return(TRUE)
}

is_this_a_valid_8_queens(validSolution)