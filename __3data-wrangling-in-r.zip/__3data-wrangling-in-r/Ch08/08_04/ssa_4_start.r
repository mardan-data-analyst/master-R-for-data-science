# Data Wrangling in R
# Social Security Disability Case Study

# Load the tidyverse
library(tidyverse)
library(lubridate)
library(stringr)

# Read in the coal dataset
ssa <- read_csv("http://594442.youcanlearnit.net/ssadisability.csv")

# Take a look at how this was imported
glimpse(ssa)

# Make the dataset long
ssa_long <- pivot_longer(ssa, !Fiscal_Year, names_to='month', values_to='applications')

# And what do we get?
print(ssa_long, n=20)

unique(ssa_long$month)

ssa_long <- ssa_long %>%
  separate(month, c('month', 'application_method'), sep='_')

print(ssa_long, n=20)

unique(ssa_long$month)

ssa_long <- ssa_long %>%
  mutate(month=substring(month, 1, 3))

unique(ssa_long$month)

unique(ssa_long$Fiscal_Year)

ssa_long <- ssa_long %>%
  mutate(Fiscal_Year=str_replace(Fiscal_Year, "FY", "20"))

unique(ssa_long$Fiscal_Year)

ssa_long$Date <- paste("01", ssa_long$month, ssa_long$Fiscal_Year)

unique(ssa_long$Date)
