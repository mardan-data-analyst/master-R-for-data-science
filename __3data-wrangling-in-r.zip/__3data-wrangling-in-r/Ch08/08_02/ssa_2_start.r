# Data Wrangling in R
# Social Security Disability Case Study


library(tidyverse)
library(lubridate)

ssa <- read_csv("http://594442.youcanlearnit.net/ssadisability.csv")