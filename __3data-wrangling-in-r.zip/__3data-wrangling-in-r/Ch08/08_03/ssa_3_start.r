# Data Wrangling in R
# Social Security Disability Case Study

# Load the tidyverse
library(tidyverse)
library(lubridate)
library(stringr)

# Read in the coal dataset
ssa <- read_csv("http://594442.youcanlearnit.net/ssadisability.csv")

# Take a look at how this was imported
glimpse(ssa)

ssl_long <- pivot_longer(ssa, !Fiscal_Year,
                         names_to='month',
                         values_to='applications')
print(ssl_long, n=20)

