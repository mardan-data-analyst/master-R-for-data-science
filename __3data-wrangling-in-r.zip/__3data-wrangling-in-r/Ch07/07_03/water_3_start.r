# Data Wrangling in R
# Austin Water Quality Case Study

# Load in the libraries that we'll need
library(tidyverse)
library(stringr)
library(lubridate)

# Read in the dataset
water <- read_csv('/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/austinwater.csv')

# Let's take a look at what we have
glimpse(water)


water <- water %>%
  select(SITE_NAME, SITE_TYPE, SAMPLE_DATE, PARAM_TYPE, PARAMETER, RESULT, UNIT)

glimpse(water)

water <- water %>%
  rename(siteName=SITE_NAME, siteType=SITE_TYPE, sampleDate=SAMPLE_DATE,
         parameterType=PARAM_TYPE, parameter=PARAMETER, result=RESULT,
         unit=UNIT)
glimpse(water)

unique(water$parameter)

water %>%
  filter(str_detect(parameter, 'PH')) %>%
  select(parameter) %>%
  unique()

unique(water$parameterType)

filtered_water <- water %>%
  filter(parameterType=='Alkalinity/Hardness/pH' |
           parameterType=='Conventionals')

glimpse(filtered_water)

unique(filtered_water$parameter)

filtered_water <- water %>%
  filter(parameter=='PH' | parameter=='WATER TEMPERATURE')

glimpse(filtered_water)
  