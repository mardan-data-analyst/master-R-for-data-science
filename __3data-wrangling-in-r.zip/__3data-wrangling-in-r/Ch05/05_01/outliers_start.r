# Data Wrangling in R
# 5.1 Detecting Outliers
#

# Load the tidyverse
library(tidyverse)

# Read in the Medicare payments dataset
names <- c("DRG", "ProviderID", "Name", "Address", "City", "State", "ZIP", "Region", "Discharges", "AverageCharges", "AverageTotalPayments", 
           "AverageMedicarePayments")
types = 'ccccccccinnn'
inpatient <- read_tsv('http://594442.youcanlearnit.net/inpatient.tsv', col_names = names, skip=1, col_types = types)

ggplot(data=inpatient) + 
  geom_histogram(mapping=aes(x=AverageCharges))

ggplot(data=inpatient) +
  geom_boxplot(mapping=aes("charges", AverageCharges))


ggplot(data=inpatient) +
  geom_boxplot(mapping=aes(State, AverageCharges))

inpatient %>%
  filter(AverageCharges>500000) %>%
  ggplot() +
  geom_point(mapping=aes(DRG, AverageCharges)) +
  theme(axis.text.x = element_text(angle=90, vjust=1, hjus=1))

