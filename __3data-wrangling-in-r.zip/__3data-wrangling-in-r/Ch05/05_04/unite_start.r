# Data Wrangling in R
# 5.4 Combining Columns with unite()
#

# Load the tidyverse and the food inspections dataset
library(tidyverse)

names <- c("ID", "DBAName", "AKAName", "License", "FacilityType", "Risk", "Address", 
           "City", "State", "ZIP", "InspectionDate", "InspectionType", "Results",
           "Violations", "Latitude","Longitude","Location")

inspections <- read_csv('/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inspections.csv', 
                        col_names=names, skip=1)

glimpse(inspections)

regional_inspections <- unite(inspections, Region, City, State, sep=", ")

glimpse(regional_inspections)

regional_inspections2 <- unite(inspections, Region, City, State, sep=", ", remove=FALSE)
glimpse(regional_inspections2)