# Data Wrangling in R
# 3.6 Importing Fixed Width Files into R

library(tidyverse)

?read_fwf

names <- c("Name", "Title", "Department", "Salary")
lengths <- c(32, 50, 24, NA )
widths <- fwf_widths(lengths, names)

employees <- read_fwf("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/chicagoemployees.txt",
                      widths, skip=1)

glimpse(employees)