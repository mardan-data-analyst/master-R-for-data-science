# Data Wrangling in R
# 3.2 Importing CSV Files into R

library(tidyverse)

inspection <- read_csv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inspections.csv")

glimpse(inspection)

?read_csv

names <- c("ID", "DBAName", "Licence", "FacilityType", "Risk",
           "Address", "City", "State", "Zip", "InspectionDate", "InspectionType",
           "Results", "Violations", "Latitude", "Longitude", "Location")

# PROBLEM 1
## Loads first row as an observation

inspection <- read_csv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inspections.csv",
                       col_names=names)
glimpse(inspection)

# SOLUTION 1
inspection <- read_csv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inspections.csv",
                       col_names = names, skip=1)
glimpse(inspection)