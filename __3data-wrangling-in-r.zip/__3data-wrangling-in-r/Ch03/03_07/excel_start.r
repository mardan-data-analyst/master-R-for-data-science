# Data Wrangling in R
# 3.7 Importing Excel Files into R

library(tidyverse)
library(readxl)

breakfast <- read_excel("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/breakfast.xlsx",
                        skip=3)

?read_excel

names <- c("Year", "FreeStudents", "ReducedStudents", "PaidStudents",
           "TotalStudents", "MealsServed", "PercentFree")


breakfast <- read_excel("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/breakfast.xlsx",
                        skip=5, col_names=names)


breakfast <- breakfast %>%
  mutate(FreeStudents=FreeStudents*1000000,
         ReducedStudents=ReducedStudents*1000000,
         PaidStudents=PaidStudents*100000,
         TotalStudents=TotalStudents*100000,
         MealsServed=MealsServed*1000000,
         PercentFree=PercentFree/100)

glimpse(breakfast)