# Data Wrangling in R
# 3.5 Importing Delimited Files into R

library(tidyverse)

?read_delim

stoppages <- read_delim("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/workstoppages.txt",
                        "^")

glimpse(stoppages)