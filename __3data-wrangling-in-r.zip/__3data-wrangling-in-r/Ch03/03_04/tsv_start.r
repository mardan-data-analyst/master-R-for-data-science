# Data Wrangling in R
# 3.4 Importing TSV Files into R

library(tidyverse)

inpatient <- read_tsv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inpatient.tsv")

glimpse(inpatient)

?read_tsv

names <- c("DRG", "ProviderID", "Name", "Address", "City", "State", "ZIP", "Region",
           "Discharges", "AverageCharges", "AverageTotalPayments",
           "AverageMedicarePayments")

inpatient <- read_tsv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inpatient.tsv",
                      col_names=names, skip=1)

glimpse(inpatient)

types1 <- c('cccccccciccc')

inpatient <- read_tsv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inpatient.tsv",
                      col_names=names, skip=1, col_types=types1)
glimpse(inpatient)

## this causes error
types2 <- c('cccccccciddd')
inpatient <- read_tsv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inpatient.tsv",
                      col_names=names, skip=1, col_types=types2)

glimpse(inpatient)

# this is better
types3 <- c('ccccccccinnn')
inpatient <- read_tsv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/inpatient.tsv",
                      col_names=names, skip=1, col_types=types3)

glimpse(inpatient)