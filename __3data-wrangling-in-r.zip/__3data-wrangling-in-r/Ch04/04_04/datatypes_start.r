# Data Wrangling in R
# 4.4 Converting Data Types

foulshots <- c(18, 22, 15, 13, 5)
sum(foulshots)

foulshots_strings <- c('18', '22', '15', '13', '5')
sum(foulshots_strings)

class(foulshots_strings)

foulshots_converted <- as.numeric(foulshots_strings)
class(foulshots_converted)
sum(foulshots_converted)

is.numeric(foulshots)
is.character(foulshots)

is.numeric(foulshots_strings)
is.character(foulshots_strings)

names <- c("Mike", "Rae", "Dennis", "Sally", "Ian", "Sue")
teams <- c(1, 1, 1, 2, 2, 2)
assignments <- tibble(names, teams)

assignments <- assignments %>%
  mutate(teams=as.factor(teams))

assignments

is.factor(assignments$names)
is.factor(assignments$teams)