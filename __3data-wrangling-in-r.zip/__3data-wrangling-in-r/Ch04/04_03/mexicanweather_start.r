# Data Wrangling in R
# 4.3 Making Long Datasets Wide with pivot_wider()

library(tidyverse)

weather <- read_csv("http://594442.youcanlearnit.net//mexicanweather.csv")

weather

?pivot_wider

weather_wide <- pivot_wider(weather, names_from="element", values_from="value")

weather_wide