# Data Wrangling in R
# 4.5 Dates and Times in R

library(tidyverse)
library(lubridate)

weather <- read_csv("http://594442.youcanlearnit.net//mexicanweather.csv")

weather

weather <- weather %>%
  mutate(year=year(date), month=month(date),
         day=day(date))

wday('2018-04-01')
yday('2018-04-01')

mdy('04/01/2018')
mdy('04/01/18')

dmy('04/01/18')