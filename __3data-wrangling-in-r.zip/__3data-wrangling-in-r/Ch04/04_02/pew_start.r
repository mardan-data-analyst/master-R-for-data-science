# Data Wrangling in R
# 4.2 Making Wide Datasets Long with pivot_wider()
#

library(tidyverse)


pew <- read_csv("/home/mardan/Desktop/master-r-for-data-science/__3data-wrangling-in-r/Exercise Files/pew.csv")

pew

?pivot_longer

pew_long <- pivot_longer(pew, !religion, names_to='income',
                         values_to='freq')

pew_long
