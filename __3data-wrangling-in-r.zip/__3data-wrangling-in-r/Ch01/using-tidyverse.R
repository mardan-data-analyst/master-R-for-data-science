library(tidyverse)

qplot(hp, mpg, data=mtcars)

# updating tidyverse

tidyverse_update()