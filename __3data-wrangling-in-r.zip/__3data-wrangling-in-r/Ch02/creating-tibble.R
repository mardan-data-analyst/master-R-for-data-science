library(tidyverse)
library(dplyr)

# Building tibbles

CO2

CO2_tibble <- as_tibble(CO2)

CO2_tibble

# adjust the print view of tibble
print(CO2_tibble)
print(CO2_tibble, n=20)
print(CO2_tibble, n=Inf)

names <- c("Mike", "Renee", "Matt", "Chris", "Ricky")
birth_year <- c(2000, 2001, 2002, 2003, 2004)
eye_color <- c("blue", "brown", "hazel", "brown", "blue")

people <- tibble(names, birth_year, eye_color)
print(people)

# Subsetting tibbles

people$eye_color
unique(people$eye_color)

people[["eye_color"]]
people[[3]]

# Filtering tibbles
blue_eyes <- filter(people, eye_color=="blue")
blue_eyes

filter(people, birth_year>2002)

filter(people, eye_color=="blue" | birth_year>2002)
filter(people, eye_color=="blue" & birth_year>2002)