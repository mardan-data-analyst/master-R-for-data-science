# Question 1
## the summary() and table() functions

# Question 2
## the boxplots.stats() function

# Question 3
## cor.test(df$variable, df$variable)

# Question 4
## lm(df$volunteering ~ df$museum) %>% abline()

# Question 5
## ct <- table(df$variable, df$variable)
## ct

