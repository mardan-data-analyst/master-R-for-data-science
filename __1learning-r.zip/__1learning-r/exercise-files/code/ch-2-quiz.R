a1 <- array(c( 1:18), c(3, 6, 1))
a1

seq(30, 0, by = -3)